# Haushaltsbuch

Schlichtes Haushaltsbuch für Windows 10/11 und Mac (Electron). Monats- und Jahresansicht, Übertrag, Daueraufträge, Monatsbudget pro Kategorie, CSV-Import von Kontoauszügen, Sicherung/Wiederherstellung.

Daten liegen lokal als JSON (Windows: `%APPDATA%\Haushaltsbuch`, Mac: `~/Library/Application Support/Haushaltsbuch`).

## Entwickeln
    npm install
    npm start

## Windows-Installer
Unpacked-App mit `npx electron-builder --win dir --x64`, danach `installer/haushaltsbuch.nsi` mit makensis kompilieren
(`-DSRCDIR=<win-unpacked> -DOUTDIR=<Ausgabe> -DICON=build/icon.ico`).

## Kleine Updates (ohne neues Setup)
Solange die Electron-Version gleich bleibt, ändert sich nur `resources/app.asar` (der Programmcode, ca. 100 KB).
1. Version in `package.json` anheben (z. B. 1.4.1 → 1.4.2; Major.Minor bleibt gleich).
2. `npx electron-builder --win dir --x64` (erzeugt `release/win-unpacked/resources/app.asar`).
3. `MAKENSIS=<pfad/zu/makensis> node tools/make-update.js release/win-unpacked/resources/app.asar <ausgabe>`

Ergebnis: `Haushaltsbuch-Update-<v>.exe` (Windows) und `Haushaltsbuch-Update-<v>-Mac.sh` (Mac). Beide prüfen die installierte
Version, passen nur auf dieselbe Major.Minor-Serie und stellen bei Fehlern die alte Version wieder her.
Wechselt die Electron-Version, ist ein neues vollständiges Setup mit neuer Minor-Version nötig (z. B. 1.5.0).

## Tests
`tests/` enthält jsdom-Tests (`smoke*.js`, `imp1.js`); Aufruf z. B. `node tests/smoke5.js` (benötigt `npm i jsdom`).
