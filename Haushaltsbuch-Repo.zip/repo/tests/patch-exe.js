const fs = require('fs');
const ResEdit = require('resedit');
const exePath = process.argv[2];
const icoPath = process.argv[3];

const exe = ResEdit.NtExecutable.from(fs.readFileSync(exePath));
const res = ResEdit.NtExecutableResource.from(exe);

// Icon ersetzen
const groups = res.entries.filter((e) => e.type === 14);
console.log('icon groups before:', groups.map((g) => `${g.id}/${g.lang}`).join(', '));
const iconFile = ResEdit.Data.IconFile.from(fs.readFileSync(icoPath));
const g = groups[0];
ResEdit.Resource.IconGroupEntry.replaceIconsForResource(res.entries, g.id, g.lang, iconFile.icons.map((i) => i.data));

// Versionsinfo (Name im Task-Manager statt "Electron")
const vi = ResEdit.Resource.VersionInfo.fromEntries(res.entries)[0];
vi.setStringValues({ lang: 1033, codepage: 1200 }, {
  FileDescription: 'Haushaltsbuch',
  ProductName: 'Haushaltsbuch',
  InternalName: 'Haushaltsbuch',
  OriginalFilename: 'Haushaltsbuch.exe',
  FileVersion: '1.4.0',
  ProductVersion: '1.4.0',
  LegalCopyright: ''
});
vi.outputToResourceEntries(res.entries);

res.outputResource(exe);
fs.writeFileSync(exePath, Buffer.from(exe.generate()));
console.log('patched', exePath);
