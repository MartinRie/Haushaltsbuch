'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const { checkData, extract } = require('./validate');
const { decodeBuffer } = require('./importer');

const dataFile = () => path.join(app.getPath('userData'), 'haushaltsbuch.json');

function defaultData() {
  return {
    version: 1,
    categories: [
      { name: 'Wohnen', type: 'expense' },
      { name: 'Lebensmittel', type: 'expense' },
      { name: 'Mobilität', type: 'expense' },
      { name: 'Freizeit', type: 'expense' },
      { name: 'Sonstiges', type: 'expense' },
      { name: 'Gehalt', type: 'income' },
      { name: 'Sonstige Einnahmen', type: 'income' }
    ],
    transactions: []
  };
}

function isValid(d) {
  return d && typeof d === 'object' && Array.isArray(d.categories) && Array.isArray(d.transactions);
}

ipcMain.handle('data:load', () => {
  const file = dataFile();
  const version = app.getVersion();
  try {
    if (!fs.existsSync(file)) return { data: defaultData(), file, version };
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!isValid(parsed)) throw new Error('Die Datendatei hat ein unerwartetes Format.');
    return { data: parsed, file, version };
  } catch (e) {
    return { error: String(e && e.message ? e.message : e), file, version };
  }
});

ipcMain.handle('data:save', (_event, data) => {
  if (!isValid(data)) throw new Error('Ungültige Daten.');
  const file = dataFile();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  if (fs.existsSync(file)) {
    fs.copyFileSync(file, file.replace(/\.json$/, '.bak.json'));
  }
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmp, file);
  return true;
});

ipcMain.handle('data:export-csv', async (event, csv) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  const res = await dialog.showSaveDialog(win, {
    title: 'Buchungen exportieren',
    defaultPath: 'Haushaltsbuch.csv',
    filters: [{ name: 'CSV-Datei', extensions: ['csv'] }]
  });
  if (res.canceled || !res.filePath) return null;
  fs.writeFileSync(res.filePath, '﻿' + String(csv), 'utf8');
  return res.filePath;
});

ipcMain.handle('data:backup', async (event, data) => {
  if (!isValid(data)) throw new Error('Ungültige Daten.');
  const win = BrowserWindow.fromWebContents(event.sender);
  const stamp = new Date().toLocaleDateString('sv-SE');
  const res = await dialog.showSaveDialog(win, {
    title: 'Sicherung speichern',
    defaultPath: path.join(app.getPath('documents'), `Haushaltsbuch-Sicherung-${stamp}.json`),
    filters: [{ name: 'Haushaltsbuch-Sicherung', extensions: ['json'] }]
  });
  if (res.canceled || !res.filePath) return null;
  const payload = { app: 'haushaltsbuch', exportedAt: new Date().toISOString(), data };
  fs.writeFileSync(res.filePath, JSON.stringify(payload, null, 2), 'utf8');
  return res.filePath;
});

ipcMain.handle('data:restore', async (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  const res = await dialog.showOpenDialog(win, {
    title: 'Sicherung wiederherstellen',
    properties: ['openFile'],
    filters: [{ name: 'Haushaltsbuch-Sicherung', extensions: ['json'] }]
  });
  if (res.canceled || !res.filePaths.length) return null;
  const file = res.filePaths[0];
  try {
    if (fs.statSync(file).size > 50 * 1024 * 1024) return { error: 'Die Datei ist zu groß für eine Sicherung.' };
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    const data = extract(parsed);
    const problem = checkData(data);
    if (problem) return { error: problem };
    return { data, file, exportedAt: parsed && parsed.exportedAt ? parsed.exportedAt : null };
  } catch (e) {
    return { error: 'Die Datei konnte nicht gelesen werden. Ist es eine Haushaltsbuch-Sicherung?' };
  }
});

// Kontoauszug (CSV) auswählen und als Text zurückgeben; die Auswertung passiert in der Oberfläche
ipcMain.handle('data:import-csv', async (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  const res = await dialog.showOpenDialog(win, {
    title: 'Kontoauszug (CSV) auswählen',
    properties: ['openFile'],
    filters: [{ name: 'CSV-Datei', extensions: ['csv', 'txt'] }, { name: 'Alle Dateien', extensions: ['*'] }]
  });
  if (res.canceled || !res.filePaths.length) return null;
  const file = res.filePaths[0];
  try {
    if (fs.statSync(file).size > 20 * 1024 * 1024) return { error: 'Die Datei ist zu groß für einen Kontoauszug.' };
    return { text: decodeBuffer(fs.readFileSync(file)), file: path.basename(file) };
  } catch (e) {
    return { error: 'Die Datei konnte nicht gelesen werden.' };
  }
});

// Kopie der aktuellen Datendatei, bevor eine Sicherung eingespielt wird
ipcMain.handle('data:safety-copy', () => {
  const file = dataFile();
  if (!fs.existsSync(file)) return null;
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const target = file.replace(/\.json$/, `.vor-wiederherstellung-${stamp}.json`);
  fs.copyFileSync(file, target);
  return target;
});

ipcMain.handle('data:reveal', () => {
  const file = dataFile();
  if (fs.existsSync(file)) shell.showItemInFolder(file);
  else shell.openPath(path.dirname(file));
  return true;
});

function createWindow() {
  const win = new BrowserWindow({
    width: 1180,
    height: 740,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#F3F5F6',
    title: 'Haushaltsbuch',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.loadFile('index.html');
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
}

app.whenReady().then(() => {
  if (process.platform === 'win32') Menu.setApplicationMenu(null);
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
